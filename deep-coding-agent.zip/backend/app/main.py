"""FastAPI entrypoint.

Wires the MongoDB checkpointer (durable threads), mounts a default agent and the
per-repo workspace routes, and enables CORS for the frontend.

Run:
    uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from langgraph.checkpoint.mongodb.aio import AsyncMongoDBSaver

from .config import settings
from .workspaces import router as repos_router, mount_default_agent


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with AsyncMongoDBSaver.from_conn_string(
        settings.mongodb_uri, db_name=settings.mongodb_db
    ) as checkpointer:
        # MongoDB needs no setup() call; collections are created lazily.
        app.state.checkpointer = checkpointer
        mount_default_agent(app, checkpointer)
        try:
            yield
        finally:
            # Stop any per-repo graphify MCP servers we started.
            from . import graphify
            graphify.stop_all()


app = FastAPI(title="Deep Coding Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(repos_router)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
